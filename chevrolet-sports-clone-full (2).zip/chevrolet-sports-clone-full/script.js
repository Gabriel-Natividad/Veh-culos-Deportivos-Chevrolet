// Simulación de comportamiento en la sección Comparar (futura funcionalidad)
document.addEventListener('DOMContentLoaded', () => {
  console.log('Página cargada. Aquí podrías implementar lógica de comparación o formularios.');
});